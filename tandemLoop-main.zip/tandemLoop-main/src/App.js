import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <div className="header"></div>
      <div className="flex-container">
        <div className="left">
          <div className="lflex"></div>
          <div className="lflex"></div>
          <div className="lflex"></div>
          <div className="lflex"></div>
        </div>
        <div className="right"></div>
      </div>
      <div id="footer"></div>
    </div>
  );
}
